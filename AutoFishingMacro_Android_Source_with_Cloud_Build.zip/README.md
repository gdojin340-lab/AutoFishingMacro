# 자동낚시 매크로 (Android)

이 프로젝트는 Android 접근성 서비스를 이용해 지정한 한 지점을 반복 터치하는 예제 앱입니다.

## 동작 주기
- 같은 좌표를 4초간 누르기
- 12초간 짧은 터치 반복
- 10초 대기
- STOP을 누를 때까지 반복

## 빌드 방법 (PC 없이 GitHub Actions)
1. 이 ZIP의 압축을 풀지 않고 GitHub 저장소 루트에 업로드합니다.
2. 저장소에서 Add file → Create new file을 선택합니다.
3. 파일 이름을 `.github/workflows/build.yml` 로 입력합니다.
4. 아래 워크플로 내용을 붙여 넣고 Commit changes를 누릅니다.

```yaml
name: Build Android APK
on:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - name: Unpack project archive
        run: |
          unzip -o AutoFishingMacro_Android_Source_with_Cloud_Build.zip -d project
          cp -a project/. .
      - name: Build APK
        run: gradle assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: AutoFishingMacro-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

5. 저장소의 Actions 탭에서 Build Android APK → Run workflow를 누릅니다.
6. 빌드가 끝나면 Artifacts에서 APK를 다운로드합니다.

## 사용 시 주의
- 좌표는 화면 해상도와 게임 UI에 따라 달라집니다. 앱에서 X/Y 좌표를 조정하세요.
- 접근성 서비스와 다른 앱 위에 표시 권한을 직접 허용해야 합니다.
- 자동 터치가 게임의 이용약관에 어긋날 수 있으니 게임 규칙을 확인하세요.
- 접근성 서비스는 민감한 권한입니다. 이 앱은 화면 내용을 읽거나 인터넷으로 전송하지 않지만, 본인이 직접 빌드한 코드만 설치하고 신뢰할 수 있는 용도로 사용하세요.
