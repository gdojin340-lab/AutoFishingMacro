package com.example.autofishingmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    companion object { var instance: MacroAccessibilityService? = null }
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var tapEndAt = 0L
    private var x = 540f
    private var y = 900f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val prefs = getSharedPreferences("macro", MODE_PRIVATE)
        x = prefs.getInt("x", 540).toFloat()
        y = prefs.getInt("y", 900).toFloat()
    }

    fun startMacro() {
        if (running) return
        val prefs = getSharedPreferences("macro", MODE_PRIVATE)
        x = prefs.getInt("x", 540).toFloat()
        y = prefs.getInt("y", 900).toFloat()
        running = true
        runCycle()
    }

    fun stopMacro() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun runCycle() {
        if (!running) return
        // 1) Hold the same point for 4 seconds.
        dispatchTouch(4000L)
        handler.postDelayed({
            if (!running) return@postDelayed
            // 2) Rapid taps for 12 seconds.
            tapEndAt = System.currentTimeMillis() + 12000L
            rapidTap()
        }, 4100L)
    }

    private fun rapidTap() {
        if (!running) return
        if (System.currentTimeMillis() >= tapEndAt) {
            handler.postDelayed({ if (running) runCycle() }, 10000L)
            return
        }
        dispatchTouch(70L)
        handler.postDelayed({ rapidTap() }, 100L)
    }

    private fun dispatchTouch(duration: Long) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopMacro() }
    override fun onDestroy() {
        stopMacro()
        instance = null
        super.onDestroy()
    }
}
