package com.example.autofishingmacro

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var view: LinearLayout? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (view != null) return START_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xEE222222.toInt())
        }
        val start = Button(this).apply {
            text = "START"
            setOnClickListener {
                val svc = MacroAccessibilityService.instance
                if (svc == null) Toast.makeText(this@OverlayService, "접근성 서비스를 먼저 켜주세요", Toast.LENGTH_LONG).show()
                else svc.startMacro()
            }
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener { MacroAccessibilityService.instance?.stopMacro() }
        }
        val close = Button(this).apply {
            text = "닫기"
            setOnClickListener { stopSelf() }
        }
        layout.addView(start); layout.addView(stop); layout.addView(close)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 160 }
        windowManager?.addView(layout, params)
        view = layout
        return START_STICKY
    }

    override fun onDestroy() {
        view?.let { windowManager?.removeView(it) }
        view = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
