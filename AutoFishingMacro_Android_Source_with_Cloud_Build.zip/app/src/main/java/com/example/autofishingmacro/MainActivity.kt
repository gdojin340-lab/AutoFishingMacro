package com.example.autofishingmacro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "자동낚시 매크로"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "터치할 화면 좌표를 설정한 뒤 권한을 켜고 오버레이를 시작하세요.\n기본 동작: 4초 누르기 → 12초 빠른 탭 → 10초 대기 반복"
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val xInput = EditText(this).apply {
            hint = "X 좌표 (기본 540)"
            inputType = 2
            setText("540")
        }
        val yInput = EditText(this).apply {
            hint = "Y 좌표 (기본 900)"
            inputType = 2
            setText("900")
        }
        val save = Button(this).apply {
            text = "좌표 저장"
            setOnClickListener {
                getSharedPreferences("macro", MODE_PRIVATE).edit()
                    .putInt("x", xInput.text.toString().toIntOrNull() ?: 540)
                    .putInt("y", yInput.text.toString().toIntOrNull() ?: 900).apply()
            }
        }
        val overlay = Button(this).apply {
            text = "다른 앱 위에 표시 권한 설정"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val accessibility = Button(this).apply {
            text = "접근성 서비스 설정"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "제어 버튼 띄우기"
            setOnClickListener {
                val x = xInput.text.toString().toIntOrNull() ?: 540
                val y = yInput.text.toString().toIntOrNull() ?: 900
                getSharedPreferences("macro", MODE_PRIVATE).edit().putInt("x", x).putInt("y", y).apply()
                startService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }
        listOf(title, info, xInput, yInput, save, overlay, accessibility, start).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 16
            })
        }
        setContentView(layout)
    }
}
